
board = ["", "", "", "", "", "", "", "", ""]



function makeMove(id) {
  let squareid = id.charAt(id.length - 1)
  console.log("squareid is " + squareid)
  
  if (board[squareid-1] == "") {
    $('#' + id).html('<span class="fa fa-times"></span>')
    board[squareid-1] = "X"
    sendRequest(board)
  } 
  else {
    console.log("its not empty")
  }
  showBoard()
}

function sendRequest(board) {
  fetch('localhost:8000/move', {
    method: 'POST',
    headers: {
        'Accept': 'application/json',
    },
    body: JSON.stringify(board)
})
.then(response => response.text())
.then(text => console.log(text))
}

function makeMove(id) {
  let squareid = id.charAt(id.length - 1)
  console.log("squareid is " + squareid)
  if (board[squareid-1] == "") {
  $('#' + id).html('<span class="fa fa-times"></span>')
  board[squareid-1] = "X"
  } else {
  console.log("its not empty")
  }
  showBoard()
}


function showBoard() {
  console.log("board state: " + board) 

}
